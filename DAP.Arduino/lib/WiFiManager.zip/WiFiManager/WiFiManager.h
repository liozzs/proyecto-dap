/**************************************************************
   WiFiManager is a library for the ESP8266/Arduino platform
   (https://github.com/esp8266/Arduino) to enable easy
   configuration and reconfiguration of WiFi credentials using a Captive Portal
   inspired by:
   http://www.esp8266.com/viewtopic.php?f=29&t=2520
   https://github.com/chriscook8/esp-arduino-apboot
   https://github.com/esp8266/Arduino/tree/master/libraries/DNSServer/examples/CaptivePortalAdvanced
   Built by AlexT https://github.com/tzapu
   Licensed under MIT license
 **************************************************************/

#ifndef WiFiManager_h
#define WiFiManager_h

#include <ESP8266WiFi.h>
#include <ESP8266WebServer.h>
#include <DNSServer.h>
#include <memory>

extern "C" {
  #include "user_interface.h"
}

const char HTTP_HEAD[] PROGMEM            = "<!DOCTYPE html><html lang=\"en\"><head><meta name=\"viewport\"content=\"width=device-width,initial-scale=1,user-scalable=no\"/><title>{v}</title>";
const char HTTP_STYLE[] PROGMEM           = "<style> .c{text-align:center;}div,input{padding:5px;font-size:1em;}input{width:95%;}body{text-align:center;font-family:verdana;}button{border:0;border-radius:0.3rem;background-color:#1fa3ec;color:#fff;line-height:2.4rem;font-size:1.2rem;width:100%;} .q{float:right;width:64px;text-align:right;} .l{background:url(\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAMAAABEpIrGAAAALVBMVEX///8EBwfBwsLw8PAzNjaCg4NTVVUjJiZDRUUUFxdiZGSho6OSk5Pg4eFydHTCjaf3AAAAZElEQVQ4je2NSw7AIAhEBamKn97/uMXEGBvozkWb9C2Zx4xzWykBhFAeYp9gkLyZE0zIMno9n4g19hmdY39scwqVkOXaxph0ZCXQcqxSpgQpONa59wkRDOL93eAXvimwlbPbwwVAegLS1HGfZAAAAABJRU5ErkJggg==\")no-repeat left center;background-size:1em;} </style>";
const char HTTP_SCRIPT[] PROGMEM          = "<script>function c(l){document.getElementById('s').value=l.innerText||l.textContent;document.getElementById('p').focus();} </script>";
const char HTTP_HEAD_END[] PROGMEM        = "</head><body><div style=\"text-align:left;display:inline-block;min-width:260px;\"><div align=\"center\"><img width=\"48\"height=\"48\"align=\"middle\"src=\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFEAAABRCAYAAACqj0o2AAAgAElEQVR4nNWdd3gbVb738/d7790X0kgIAeJuS7K6Lduy3GI7bmlAilNc1SV3O3biuMQ2abJTXNQ1ktwdSmCBu/duo25h6XW5yxJIFki4sIRQ0/x9/zhnRiPbYSnLPs+b5/k+p82Mznzm+zvnzIysLMJ3/Hfxi6/x3P+8j6dfP4tn3jiL3715juiNc6H8nLqnXz+LJ199D0+++h6e4ulJXsrXUwts+9QNtv1Hx1wof6OUf6wnXnkXL7z9IT7/+vJ3RYNF39b40cUv0DvxFDRNQQiqR5DeyCCt2Y/0PX5oWgLQtFLtCZC6PQFOWfuCUFjdkJs9kJvdkJtdkJldkJtdkFvckFvcUNBUbnERmXn5uW0WN913rvj736CetikW/Cw31z+2XmpyQaC1I7dtFP33/x5f/AOgN4TYNfY4hHonVDVeaBr8KN4/gYLOcRR1TaKwcwLF3VMo6p5C8YEpmif1hV0TKOqeQHH3JDKbgshqGUVWcxCZTQFktQSR2Rwk5eYgLY8iqyWAbE5BrpzVHCB5NmXrWwLIbg6G70O3YcUeJ6slgKzmYFhbZgv5bK4/LUFkNNPtaN8ym4JIb/RDafFApHfg5OlnvzvES19dRlZLAMoaD3fy69rGUNhBABZ1T6Koa5LA4wPsmkBR5wQKOydRfGASefvGkNFE9p8PjqeWUXJCtI3ACJWzeXXZvJPOag4dN6uZgAkdPxwIu21mUyC8P7zyvPamADJoXUZzEBKjC0X7J/8xxEtffgOFxQ11A4PsllFkNAWwdk8QxZ0TKOgkAIu7p0I6MBUGtrCTuHF9zxQym4PIoJ3KaqadC4Ma6nAGDwjrCPbEMuadJO9km+Zswx6P2yfA9YFfzz8m+1kZzQRWRhNpZ/vE5jOaA1DV+qCq9X07xKzmAAUY4K72+s4JFHROEPex4ct3YdckF+KFncSRhZ2TyGikH94UJJ1jO9oU6jCBsNAJ8h0S4GBk8E6Wg886hoPAO04T+QwWTGYTr72Z7R8F1hjkLgobzvxjsFLV+rChc3phiF2jT0BpddOxhBygqIMALOycQHHXFIoOhIMs6pokIdw1gUKaL+mZQk7bKM8d8zsXclmQ56YgByqzaQ70pjn78o/BPxb/M5p4x28KEkjNwXlQuH357Y3zt8toCiKjMYjMxgDEBhdcjz4fDvGji19CpLeTQZde1YJ94yjsnOTClXMeC7KLQCzoJAALOgnE4p4pZDQGoGnkdaiR17HG0AlzwBp5aXM4tHkAm0PHyOBByGgMHSeTzfNSPtQMXr2mkV48PrjGENjQsckF1TQGkd7gh9jgwvXrsyGIvRNPQVXj5Qbx3NYgijonUEBDlZ08insIxKLuSRSzIUxBrqP5dR0T0DQEoGE/vIknXkfZE8lomn+yYSfM23fBtIkFscAJzwFH+hTg6jVhLgvMSUm7ht2+MQAN77hSoxue/3whBDGjKYCMJj9y9pAlQzENYXYiKTowiZJe6sIDxIWFdJwspNsWdJAJJauZ98G8E9HMhTEHgGYOHE1jIAy2hn9iPIVBaZz7WQGunQNA68Kg8ECFlZuC0DT6Q8do8HP7ptYx3Ni46NPPv4ZAZyfLiOYAivazY+Akirp54HpImXVlAXVqQecE1nUQmEUHppDeQDsR1pHQybCd18y5slxH557wAi7I4IGYC2QhcBkNfgKAQtA0BrgyC4Yrs8fk52k7ux+r+KoRAvHZt96H1ORCVksA+XvHQgvpA5Mo7plEce8USnomUdQzheLuSRR3TWFd9zgKusZR0DWJdR3jKOgga8PcfWPcB2TwO8m7glyHeVdUYnRBbHBBQiU2OCExOOeVxfyy0U3yRjfddk67wQWJwYnkGl8ISIMf6bzP1jT4kU6hcikLaQ5oDX/7BiKB1o6zH32GRU+88i6kJjdyWoIo7ppAcdcEig5MoPjAJEp6plDSQ1xYeIA6sGsCBV0TyO8aR37HOAo6yThY0jtJDx760PQ50DTsSVB3pNb6UHrv/Xjy5TP45fNvz9dzc/LPLdDO1j33lznlt/HUK2dQO/ILJNd4oakP9YntYzofWgOD9Hpa3zAHMM996fVku/R6BiK9HS+/cx6Lnnz1PUjNLhR3jKOgi4RkMR0Di3unSHpgEoXdUyjsJgDXdY0jv3Mc+Z0TyKd3MgVdE1DXBZDe6IemnkE618kAr7M0TyU1unD/k6/RhcK1H6nrC9QBf3jjLBL1TtKfegaaegaaBobrYwgOC5IhdfW8bepZeOz+AWjqGQi1Drzy1wtY9OQr7yK1zkOWMwcmQiHcO4X1vdMoOTDJzcgF3ZNY100hdkxiXec41nVOoKRnGlktAdKR+iA09QH6YX6uo+n8kKAdkpvd8P0itN76Kf49/tI7EOudFArpR3od2zcCVF1HLra6gab1JFzTqTvVXFuQpPUBaBqCEGqdeOWd81j0zOtnoW5iUNg9yYVuSe801vfNYH3vNIp6JlF4gKigewIFXeNY1zWOdZ2TyO8kDyVKDkwhrdZHADYEubAmtg85gL2qxAl+qOsZpNYxqLQ9jLIjp1F25EGUHabpkdNER0lazq+j+d2HT6P8yGmUHXkIuw8/GKo/8iB2HzmNSttDyGgMIK2OfLa6PtQndUMA6nrWiSGAZNsA155eT/bji91OqHXglXcuYNHTr5+FusXPOXB97zTW905jQ98MinunUNgziYIDEyjsJhDzO8cIvK5JsjY8MIHcvWNQ1wWgpuNJej25mmyeC4UGJhRWNHTU9QxUVi+SrV4kWz1IsnigtHiQZPZAeSNZyTZKixdKiw9Ki4/bj1WS1Yckqw9pdSww2h/ObeFg0uqYeXXquvD2tDoGafUM1yaotuPldy5g0e/eOAtNawDFPVMoofA29M1gfd8MinupC2koF3SPI79zDOs6J5DfNYG8znGU9E4jrS4ANb2C6XM6S8rsFaSqZ2GHrnRaHQOlxYsUqw+qGh+SrV6oanxz5IXK6oWqhkGydU6b1Ydkmk+yeJFk8c6HMgfIQnX8tnng6v1Iqw9tE4L45jlo2gLEfffOYOO9M9hwLwnl4p4QxMKuCazrmkBO1zTSOh5EUsfPkdn9ADTt90FknUZ8zSmIayeRXBe8YefVdTQU6v1Im1OvNHvxzeVvAMzSSeKHityKbeiYhqrGNx9IXchJaXVMKOU7r26OM2v989rV9X4ItBzEvyFr7yg29BGA61mIfTMo6SUzcuGBKeR0nUJS589R02PDzw+W4uyRFHxuE+HSUREu2RLx1qF0BLvKsbFxELHW+0Iw6+Zf+bkuUNX4kN82/k+YRq7jymXyFLpm+BdQmD3k86mT+I7ih2qYasMBs2V1nR9ptQzSahmoa0l7QtUIXv7rBSx65o1zyNobxIa+aRrG06Fw7plCYfckUrofQUPvEZw/qgD6I3HFFofLtnhc7Y/Dtf44XO2Pw5V+UsaxCLx4cC0KG0eQWDMVBi0sVOqZMMlNHtQM/Sf6Jp5Ez+gT6BkjOjD2BHrHnoD94T9h+KFnMXya6qFnufLQ6T/C9chzmHn8NepGwDz4GIFYywNCoaSyDmVh1fo5cfUssDqyfWqNj6tLq2WQWuNDQuUIceIzb56Fpi3AuY+EMoFZ2DON1AOP4KGDu4D+O/GVTQD0R+PS0UT88Wgx/F2VGNpvgKNDh9/0bsD/HpXhC5sIX/cLgIFI9LU3INZyH1L5V70u5AK2k2xZafZAZnBDZnRDanBBZnRzkuhDdzQSg4uU9aG8UOuA0uLhPGk++RjkJncICA8MC0Rd618Q1ELpvHyND/GVrBPfPAd1KxkT2VDe0DdDJoyeR/Gbw3cBtihctsXjwlEF2np6kNZ5GnEdj0NVw6CptR1D+w0Y7SqDu7Mabx3S4JItEZ/ZxMBAFP6rdzMENTNIrh0NhTHbef5J1NIxa+6J8kKKLfPbWTgqqw9ZjUEOounko1CYPGRb1kELwOCXU6zesHpWKVYv18bmU6xexFcM46W/nicQ01oDKO6d4mbmDX0zyOz9OfyHzIAtEl/ZBHjq8AaoOh+GrPMxlPa48dLhPGAgErMDsbjSH49v+hPwTX8CLtkScdEmoRLjWn8cPjiShMw6LyTW8TAI/BBJrZ2Tr/EhlQ+LzdewoMNhJFu8yGwMhCCeeBRyowspNd55wFJuCIm2cWVeSlcG5HgkjSt34CXWiemtARQemMKGPuLGor77sL3PD9juxEWbGFdscTjR1whh5y/huLeWC+2LNjEP2I0kxpc2ITAQjYqmexFvnkJqTbjbWDAp1DXsSabx2lN5IInC3ZRs8SKzIRyizOBCKs9dKTy38R3Fgk6pmVO2MhxIVQ1dclkZpFgZqKwMYvkQ1a0BFPZMo6RnCuv7ppHZ+yieOrwZX9sSQo6yxeKdI2pcs8V8R3jhumRLBI5FYrhdj2jzDFJq/PNDiHeCnGvYOp5DSJ5uR5Vs9iCjPhyi1ODioHBOovunWL1QWcnak4Nk8UNl9UNl8SPF6ofKwiDFGoDKEqB1AaRY/Zyid4/gpbf5TuyeQlHPJEruPYXCe+/DdVsMPguDJcbnNtEPAsg/Bgai8UxfAWJM05BbA+HhxAJlQdETZ7dRzYGtqiHbqWp8SDJ7oKlnOIhGDqKPLOAtDFIsIUApFiprKFVZGCSbfUg2+0J5C7Ngm8Lohczswhvn/pfMzurWAIoOTKKwZxLreu9H+8GDmLVF/QhY3w7ySn88PjoqQ06tAyLLOHUGK3rXYmXvTkIAU2rYenKHwjosxeqF0uRB3p7QWtN4/FFI9R6oLH4kU3gqCoPVPEAWBioKSWVhoDKHwCVbSHuyiYHS5EX+vjGoW/147exH/DGR3J1k95zG6GEzLtvifiKIRF/ahJgdiIWxuQsxpmkChTpSZQkN4vyyiuZTrAyBYiFjU4qFgdzgwabOUyGIxwhEDgwLiQJTWRgk8R1H25MtPiRZSDnJ4kMShZ1kZqA0kYvIfkEhtYXB6+99RG77CMQJFPdOQXPgITx2uJQ3Hv50YsdJb0cF7jDcD6WFgcpCrjqXWkmdip4gKbPyI9nMINnMQGbwYsP+GQ6i4fhjEOvcIWCc2ygssw9JZoYAo5CSTD4kmcjx2JTNJxl9SK3zobBrAgXdEyjsnkBqC4PX3mOd2EacWNw7hYyeh/9lEPnj5J/68qAw+5FkCfDGJIZL2ToV6xqec1QWH2QGTxhEre3nEGvddBsCKdlEYdGwTGaBmUPAkrntfEgy+aA0MVAYvNA0BlDQPc4BLOiaQEqzLwRR3epHce8UinqmkNHzEB4+vBPf2OL/RRApyGMRYPZXQGSeQGrdOA8gdYqF4YUZPXELcU6SmYFM78GG9hDETv/jSKh0Ukf5kGyizjOFYHIuM7PQGCgpQCXNKw0+ZLcG6bPU0CPBdV0TUDV7WYhnoW7zo4g+T8zpeRCDB5tw1Rb7L4P4uU2ET45KkWCcgsLgwe055Uipn0SyJRDmlCTznJM3MVBS58j0HqynEK9euYLZ61chrHJBYfRyoak0h0AqzQwHinWc0uRDkpHUKYxeJBl9yN03hvyuce61CKv8znEkN3nx2rsUIjuxFPdOI7/3PlT2OQBbJH7ccub7uDAS2sYDkNY+gNUZpVgsVGNF8nokmRmorKOcm8JCkrpHSR0k5UG8fPkygFmcfvpNROwcIXDMPiiNFBSFxo51SqMPSSY/FEYCUW7wQWXxIm8/gbWO916JpBPI75hAUpMXr7IQ2SVOUe80SvpmkNrznzh3VEXXhT8txG/6BfhDXz7uND6MxJ2HsFiUjmWyPCyV5GCJOAvisn6k1E4SeDQklaZQ+CVRB0n0HpS0T3MQL9NHYiXt05DoPASQiYBMojAJPHo8Wq8w+JBSxyB//zhyO8aRT5+j5lMH5nWQJ/t5HeNIauRBTG8NoKhnGkX06XZe7wNovvcI0H/nT+rGz2xi4Fg0UsxeKKyTWC5fh2XSXCyX52O5PB/LZLlYLFQjZmMzVHVTUJr8oZOm8JQUjFjvQXH7VBjE2etXce7C33H7tiEojAxxooGB0uiHkgJTmvxQ0DqZ3gtNUwC5+8eQt3+Mvgrhaxx5rPaPQVnvwavv8Z3YQ8K5pHcGxX0zSO19DI8fuQvX+3/Ybd53EQZiMLRPh3jzg4guqcOSxEwOYAhkHpaINFiduRPJdRNQmv1QmHxQGH2QmxgoqMQ6L0r2zYRBZN24z/NbxJW7oDD4iChABQ1dhcEHucGLjJYgcttHkdcxhtyOMfpamLxfz+scp/XjyN0/htz9Y1DUefDqexdCEIt7qRP7ZlDSN4Pig6cQZZ3BqwezMDsQ+08H+YVNhA+PKBBlOAWZ3oPFQjWWyfLmQWRBLhVnYbl8HWR6F5Is41AYKAAKQqz1Yn37qXkQr14h42N8hQsSvRdyIwMZ3ZeVwuRDTlsQa9vHkLt/FHn7CbT8znHkUqAsvLz9Y8hrH0Xu/lHI6zx4jQ+RBVjcR14RZO8dhdziR5T5FB7ruQsYiPongiSTyc76gxBbH8Aq9RYsleQsCDAMpnQtliRmQLC9D0k1k8RRRgJCovcixUIeQFy5cnmOG2fx8DN/xh2lI5AZGMj0PsiNPsj05K4ke+8o1raPInffGAVF4IWcN07q2sewdt8octtHsbZ9DPI6N1559wJ/TKTh3DeN4r5pKCwMkqx+KKwMoiz3w9ZuBY5FzHle+MN0uT8Bv+kpxp2G00jY3ofFIs0NXbiQKxcL0xFZaEVS7TQURgYyPXFX1E47Rk4/N8+NoUnmFARVbsj0Xkh1Pqhq/MjeO4qcfaPIaR/lwjSvYzyk/RRmO2lb2z6KtfvIPrJaD159l77tS28j4VzcO42NB08hrTEAhZmB0kJl9SO+ZgY7ag/i+kAsvuoX/ujJRGoIQGaewDJZHpbJcr8TwLBxMjEDq9K3QmEeg9wYgMzgg1TvxZodI/j6629w7eqVMIiz16/ibx99ilVbByHRepBW70cWBbh2L4XUPhoCt58FR5yX2z6KtfvGsLZ9DDn7xpC9bxRyFuLTb56Dui2A4h7iwvyuSciMDBQUnsLig9LCIKUugHjDOFQGNz48osTVgfgfEN5i4FgMDrZaEWt6EBEFFiwRz59MvivIpZJsLJfnQ1w1Arl5FFKdF3HlTuj6H7mhGzuZxyE2u5DVFkQ2Bbh2HwnTPM6JJGXDNncf2SaHc+EYcvaOQVrrZiGyE8sU1h+cgdLKQGb2QWFlILcyUFhJXmFhkFoXgFAXQJR2Er89UAQc+37j5Bc2Ec4dTsYa3QzEVXZuTfhDIM4dJ+O39UJhmYBM78HKu0/grbMfAbPXwiBeuUJAJjf6kNkaJGPhXuKu3HYKkXUdHSNZ9xEHku2z940ha98opDUuAvEZ1on3TkGzZxRSEwOZmYHc4ofcwiDJ7IfS4ofMzCC5LgCpwQuxnsFt1TM42mYCjq/5juOkGDgehXtqDkNkfQArUzdjmXTtjwIYNk6K1IgsaYDCMglhpQuZ9cEbuHEW//X8X5BocXJj4dp9Iefl7p/jvPZRrG0PIocCz947iqy2IDLbRiGpYSeWN84hfW8A+V2TkBi9kJn9FCKFafZDbmYgMxOoyVY/pDovpAYf7qiewpaaI7g+EIev+wXfCvFKfwIe69qE1doHEHdPJ5aINFj+I104fz2ZjtVZZZCbxnH7tiFM/frVG4Z12cBppLf4kUNdxoLL3TeKnHYCMGffKHL2ktDNppNJdtsostuCyNxLIL565gIW/e6Nc1DvDUJh9UFmZhaUnDpRZmaQWhuEVOuBTOeBVOdBrHYUcr0Hfz2UesP1JDuZxOuCEBuCWCZd+70nk++qJYkZuD27AlLjOOLKHJi9dhVXr8yZZK5dxflPPoO0xk1ClB+y1H3Ze4n7WHg5e4PI2htE1t5RZO4dRVbbKMRWJ1559zwW/f7P5yAyeyAx+iAzMcR1Jh+RmYHUTFOTD1IzA6UlAIXRB6nOA6mewBRpGdxZOYmHOu8Cjs9/cIFj0ehsqUOs4T7cmW+gC+d/PsDQEkiNmLs7IdT7cO/UUzd049H7n4Gq0Yvc9lHepMGKQqThm902iszWUQoxiMy2IMRWF145cx6LnnjtPazZ7YDM5Ifc7IfM5IfMxHCS8iQz+yE1MUiuDSBR54FU64VE64FE54VY68XKimnsbW4EjkXiC/rw4st+If56KBWrq05BWH4Si0U3vjP554HMxXJZLjL3TSLOYMdHn17C9WtXF5xk0pqYsKUOcWAQ2W1BZLVR97WSMM5qI0AzWoPI3BOAyOLEy2fOY9GvX3gXEbsdkBr98yQzslBp2eSH1EjcKNV7IdZ5kajzQKz3QqzzQKzz4Paqcawz9+OSLRFX+hOA41EoNtkgMs1gRfL6f9pk8u3Kw2KhBtKKXqS2jGLH0Qdu4MbrePyVdyC2OumyhYQxATjKwctuJfms1iAyWgPIaAsifU8QQpOTOPHXL75HIJoYDhhfUiPDweRAmvxINvsh1LohohLrCdBErRvR1X7EaRn85WAaHunchNuqTyF68z4ymfzkAImWirMRsa4KWfunITI78eSrZwBcXzCsd/efhrqZIQD3Ute1jiKTBdg2isxWAjazLQDNniDUe/wQGF3ki++/fvHdeRAlJh9JjT4KLTyspUYGSisJaZHWHZayunOXE6vK/EjQ+iCsdmGJOPMnD+OwkJbmYqVqPXI6ZpC+J4CstuCC99Wz167iwt8/g9jqQlZrEJkUHpsScKPIoC7UtAShbgkgrSUYDnHNLjskRl+YZEYCUWok0KQmBhITbTeQ8VJuYiCsdlE3ejhX3l46hIFTf0DRvhncsXMEgoph3KIsJBPKvwjkMmkublEWIqt9ElmtQchqPXA+9qcbTjLHH/w9lHUeDlpW2xwHtgaR3hKAujmAtOYg1M1BJIRB3GmH1MBAovcRGUgq1TOQGHyQGph5kuh9UFr8EFa7iLQuCKvdiKtwQGH0ht66DTyC6HInEg1B3Ja5C0u+x8OGHwtxhbIQ2e2TZCJoDUJideOLr76ad1/NTjLq5gA0LQFk0u0z6QTCObCZOFDdHERqUxACozMcIh+e2OAloAwU5By4HGT6WF5Y5YKo2gVBlRO33HUMv3vtPbBftry7+z5El9khrHZBbBzFmpImLBGqf7J1YhjE5BLkdMxwQFSNPtQ4fnHDSebJV89AYHIgszWIjD0BAnAPcWB6cwBpTUGkNQeRSt0Yb3DiJRbinTtGIDZ4IWYBGXxI1Hsh1nu5stjg5QCz9WK9FzITg4QqB0RVTkTuGkZp34PUg+RF0fK7j1G3OiGociHREEDcjqNYKs7GMuk/fob4gycWSQ7W5JYhu2MamXsCXFgmGB14/d3z8+6r2bAuH3gIKY0+ZLYGkMlzYHpLEGlNAQrQj9SmAOINNJx/9eK7uGPHCMR6HxWBKTZQ6b1I1Hu4OtaFLGS5iYFI60JCpRO33H0cX339DWavXwUwi4hdI4ivdEBQ5QqTUOuDoMqFFcnrsVSc+ZOMk0tEmRBub0P23kkKhLgxrZlBSffUgm68fu0qPvr7JSRanNC0BMMAqpsDSGsi8FKbAkhpDISc+KsX3sXtO0Y4KIk66ki9D2KdD4k6b0h6DxL1/DJZH0oNPty69QRO3P9Hbizc6/kNbt8+CEEVASyocEBQ6UQCW672QKjz47bsciz5EU9zyMOHDCyVZHPHWCbLw80CDdKbfGSWZcOzNYCMPQGILS7c99RrAGYXdOPJ03+A2OJCWhOZSFiAac0BpDSS8TClMYA4vQMvvXMBi371whncvmMYIr0HIuq4RL0XIp2HAyXSheCJ9GQJI9J7uG1EOg8kOvp96dlreO/DT7DsruOIr3BS9zmRUBlSfIUD8RUOJFS6INQHEbFhD5aIvt84yT5PXJyYiSTTSUQW6rFUkkMeRNA1YnbHDDQtwbCJImNPEJqWABS1HmCB+2p2kklt9EPVQH4HSN3sR1ozAZfS6Edqkx8pjX7E6Z0sxHexescwRDoPRBQIX4l6Ak6odXN1Qq0bQq0biXovhFo3Vmw9iWff/Bs3maxtHkPkzmEKKhwcW8ellU4IdH7ElB4lDybmjJPsk2+S5mGZdC2WirNxs0CN1RnbkNbIIHP/fUhvCRKI0lwsFmqgaQ0iY88ohUbg8fPyWg86xx6/4STzzOvvIUY3AnWTn4yFjUEaxn6qAGJ1zpATV5cOETic3Bwskc4DkZbWaWmdNgQ5arcdpQdPc5PJA0+9gWWbjyGe77xKJxJYoBUOLh9fbufqBNVexFc4sEK1EUvpwnyZLA/LFQVYpb6bg7oydRMii4xQGoeQ2fEgsjruh6S8j05Ua3FzghoK7VFk7h2HpiWAjJYQvHCYAcTp7fjw44uYnXNfzYb1LttpyGt8SG0McOBUDUQpDQHEap3k68a/fP4MVm8fgrDaDSG7YK7mwdJ6IKx2c6mArgeFWjcE1W4sv/sErl65zE0mt20bRGyZnYMVPwdeXEWoLaHCgbhyB+Kp4sqdSNAGcFuOloyT0lwsk+ZiddYOCEq7oDDZkVzvh6qegUx3DHF3NeGWpCIsFmmwVJKDmxPUkJT3IXPfNNJb/NC00J/jClMQ6c1+pDeTcN168P4bTjKfXPwcsToHVA0sQD9SGvxIbvBD1RBAjNZJ/o7lV8+fwartgyREq+dI64ag2hUOrsrF1a/cehKOnz/HTSZNjl/htq0nSNiW2xFfbkdcuZ3CIvm4MifidpNyfJkdsbvtiCtzIK7MweXjq/yI2NyN5XLyQmqpJBtLErOwWKTBYmE6kSgDSxKzsFScjcXCdKxILoaqxoGMvZNIb/IjvTlA13csTCKuTEEKjA789/N/ueF99YnTf0SCwYmUBnLxVPUMkusDSKoLILqKnVieP4Nbt50ks2i1k0CrdiGhiuQTqp1IqCJit0modiKm3A45vTO5dvUKvv7mG6wuHUbs7hHE7rYjlkKJLatq2gwAAAs9SURBVHMgjgcrdredU6g8wqsfQfSuEShqg0humEDsXa1Ykbwei4UaLBZpsESUgSWiDFrOwG3p90C8uwcZe2eQ3jyKtEY/1E1+qJsCSG8ii+T05gDUTX6kNwW4NnWTH+rmAJLrfchqHVtwpg49LgtAWeuDqo5Bcp0fybVEkZVcOL+DW7eeRAJvHZfALkWqnEiodNFlCZ1laX7FPSfw+9fOAriOa1ev4JOLn+PmTQOIr3AgdtcIBTPCgYnZNYyYXaQcsytUDk+HEVk6BKXFC4WFvKKQ14xCWT8BucWNxIrDEO3uQ2JZL2TaY0hpCEDdNoW05jGkNviR1uBHWuMcNfk5sGlNvHJjAKkNfihrfRCb3cDsNVyZA5F7XPbyGcRpnUiqJRCVNQyUtQwiKhx4kYW4cuvJ8EmAgmTz/DS+0onYCgdiKhwAZrmnIgBwdPoZ3HL3cSzf2I/lGwewbBOrfizfNIDlmwawbGM/ltH88o0DWLqxH8s2hvLRFXZEVjgRUWYnKrcjqsKBmCoH4nQuJOjdSNC5kaBzIUHrRLzWAYHBAYHegQSDEwKDC0KaCgxOCAxOCI0uCPS8NqMTAp0LcVoHoqpGcP/TbyzoxMuXL3N/cBlVaUdSDQNljQ/KGvKlhjXlLMTn3sHKLSfClh9xFQ7EVzjJgB+2PCEQY8rsiC23z3u0xJb/duFTfPC/F7+3Pvz4Is5/8hk+/PgzfPjxxbD0/McXcf7jz3D+489oeY4++QwffkLSbxX9jPMfk8/86uuvbwiQf15xWieUNaFXyHKLD2vK7HjxbdaJW06Qgb7CjrhydtAnYxkBSyCSyYGkK+45gVO/JT+CMXv9KmavEWGW/qjF7LUFNXv96o117SquXwsdi9X1n1BX5zzRYd135cplXLt6BQBw9sLfEVFuh9xKhxj60m7NbgeB+N/P/RW33HWczJplDjohOBDLTQbs7GnntZNxbunGARwcfxrvf3QRZz74hOpjnLvwKb748it8ztOlL77C119/g/9//l3Hp5e+wCO/fwtigwdSI3l9LDP7uIfXd+yiTvzFs2/jls3H58yYI2HLDnaCICDt3AQRu9uOVfecxOL1Nize0E+0nqQ3FR/FzwoO4WeFh/GzwkP4WeEh/EfBIfzbuoP493UH8W/rDuL/5B3ErVuPY8WWE2Rmr3AgptyOuHIn4iqdSKhyI0HrgkDnRkK1g/xKSF0QmvogMurn/PLT3F+j4//mGP2RNk3DKP1ZhSDSG4Pk16QaglDVMhDqnBDpXBDpXFi9YxCrdwzizl1DiK5wQGryQWHyQ27yk7ee9P3THTvteP7t81j0+9f/hqUbbXQG5c+WIxTWCGJ2zynTmTRm1wiid5JlTfTOYUSz++4cQdzuEURtH0T09kFElg4hsnQI0duHELV9CFHbBxGxbRAygwdiPVngC6qdEGnJ8kqkpa8Z9B7yDS6DFzKjBzKDh6RUcpMbcpOHyEykNLmhMHugsHihsHjJTG/20r+b9kBK95XOkczshdTs414Ryy0MZBYGCjP/7acPMgPDPf1ftX0Y5z76DIsuffkN/r3gMKJ3slBYUSg7hxG9i6zdoncOI3ongRm9a5iWyXbRu4YRtWsIUbuGyLF2jyCqlECL3j6IqG0swCFEbDlJAOrc3JNxQbUTomonEnVuiHVuiHUeSAxeyA1e+q1YL5RmAlNh8kJhpl81NvtI3uxBksWLZLOX/MGP1UN+3cTqhdzoJd+uNXnJ9iYflCYvt7/c5IXM5IXcTN63yylIGf02rsxE8lL6lJ88b/Vg1fYhAPRX6xLKHcQpOwm0mJ0hl8XwFL2Dt82uEcTQcvSOIUTtGEL0jhBYthy59SQitg0ictsgIraexJqtJyHVuiHUucijsUonBHRhn1jlQmK1ExKtG2KtCzK9FzK9l34l2Au5wQO50QOl0QuF0UtSExH7Z2NJ9C8FyF8WhC4ASX1cKjd6qUgdETlW6Fu0BJ7E4OWJPM2Pr3Qhd89UCOJ+32+xcnM/gVQ6jJidQ4jeMUghDZH6HUOIKh1CdCmFtWOIbkfqoraT9jDtGELk1pOI3DqIyC0nsGbLCYi1BJSgktwvCyrtEFY6Iax0QlTlhKjaBbHWDbHWDanODYnODZnBC5neQyCyMA0eKIweKAwsVA/92xMvcZmRoUMB+Wsr/teL2QsjN/ggN5Jjytg2Tl7uO49S+qyVyI1EHXkZ5/vFyyGIn395Gf9ecJie/CBidg5yICJZONsHEclT9I5h2s7WkXxY3Y5hRG07iagtg1hz93GItSRk48vIfXN8uR3xFSMQVDogqHBAWOWEsNJBQToh0bog1brJ93709Gsreg9kejdkejfkBiK2rDB6kGTwQGnwQEovgtTghUTnhlTvgVxHx1i9BzIDgSPTh1IWGokA+plaDyRaDxJ1bioPBNUu3E5DmYMIAAf8T2JJ8VECq3QIkaUEDAePAo7aPoTo0kFElQ4iYvsQhUfb2P220f1ouuauE0isckJQYUfcrhHE7R6mGkFCmR2CcqpKB4SVDiRWOpFY5eRASrQuyKpdkGndkLFw9J4wyfR04jGwYyp1stZNvjekJWAlrPQeSPQht0t0Hm57CVunJd/qkOjcSNS6kFjtgqjKiRVbTmDsl6/OhwgA0ioXVm0+huhtg4jeNogoOpZF0nzUtiFEbD3JzbBR2/gioRu1NbRf1LZBRGwdhKjCQQEOE+0eRuyuYcRzIEcgKB+BsNyOxAo7RBUOiKocZKLRuiCudkJa5YS02gWZ1gVptQtyrXueFDo3xNUuoiqSSqpDdZJqAklcTRwuqXZBTC+SlG2vJsDEWjdEVU4uZQGuKR1ECe9vCOdBBIBbNw1g1aYBbiIgInm2LmrrIKK2nETENjLeRVGxk0jE1kFEbDuJNVtOIqHMjoSyYcTuHEbsjiGinYOI3TnEuTG+bATxu4eRUD4MQfkIRBUjEFY4kFjlgKTKAXGlA+IqByQUpKTKGcpXEwCyahfElXaIKp2cEqtovork2TLJk4mMBczmE6tcxHXs9nSIEVY6cOf2QaRa/POW5Qv+bH5StRs3FRzGmi0nCJitNN12goDbQhSxNZQnOoGIrScI+HtOIqFsBPG7hhGzYwgxOwYRy1PcziGiXcOI2z1EIJaNQFA+DFH5CEQVdiSWjyCx0oHECjsBWWmHqNKOxKoQVAlNheUjENGTFVY4kFjpgLDCToaHCjtElaRORNsSKx0QVzlJfZUTYpqKqkL1IjpOx5WPYMXmYyhu+w6/+M7/d3TiGdxccBhLCo9g9V3HEHHPiRC8LScQseVEGMCIe04g4h4Cb83dJxC/k7gumo6VMaWDiCk9iZjtJxG3YxBxpeEw43cOIWH3MAS7h2hoE4kq7BQqUWI5T5V2JFbaISyzQ1RuJ/uVkYsQtn/FSOjCUInKR5BYQcZitl5YQS6AkI7RMbuGsOruY1h1z3GM/vcrN0L17f8LxvXrszg68TskVbvxbzn34j/W3oub8g7hpryDuCn/EP5v/kFON+Ufwk15h/B/8w5ieckRLCs5gpsLj2BxEVXhYSwpOoylRYextPgwlpUcxrLiw1hecoRow1Hcsv4oSTcdxYpNNqzaZMOtd/Vj5WYbbt1sw6rNNtxG01V32bDq7n6s2HQUKzf2Y+WmfqzcaMOtbH6TjaYhrdhkw62bB4g2DeDWTf1Yubkft27uxypav3LzAJZvsOGWjTbk1Afhe/TFb0P0jyHO/Xfmg0/x7Bt/w5/efB9/evN9PMcTv+6Ftz7Ac39+n6cbl5//8wd4/s/v4/m3PpinF9j0fz7A8/9D0hfeCuUX2ue76AVeutBxzl64+H2w4P8BoXRD4mtc0voAAAAASUVORK5CYII=\" /></div>";
const char HTTP_PORTAL_OPTIONS[] PROGMEM  = "<form action=\"/wifi\"method=\"get\"><button>Configurar WiFi</button></form><br/><form action=\"/0wifi\"method=\"get\"><button>Configurar WiFi(Sin Escaneo)</button></form><br/><form action=\"/i\"method=\"get\"><button>Info</button></form><br/><form action=\"/r\"method=\"post\"><button>Resetear</button></form>";
const char HTTP_ITEM[] PROGMEM            = "<div><a href='#p'onclick='c(this)'>{v}</a>&nbsp;<span class='q{i}'>{r}%</span></div>";
const char HTTP_FORM_START[] PROGMEM      = "<form method='get'action='wifisave'><input id='s'name='s'length=32 placeholder='SSID'><br/><input id='p'name='p'length=64 type='password' placeholder='contrasena'><br/>";
const char HTTP_FORM_PARAM[] PROGMEM      = "<br/><input id='{i}'name='{n}'length='{l}'placeholder='{p}'value='{v}' {c}>";
const char HTTP_FORM_END[] PROGMEM        = "<br/><button type='submit'>Guardar</button></form>";
const char HTTP_SCAN_LINK[] PROGMEM       = "<br/><div class=\"c\"><a href=\"/wifi\">Escanear</a></div>";
const char HTTP_SAVED[] PROGMEM           = "<div>Credenciales guardadas<br/>Conectando el DAP a la red.<br/>En caso de falla reconfigure la red.</div>";
const char HTTP_END[] PROGMEM             = "</div></body></html>";



#define WIFI_MANAGER_MAX_PARAMS 10

class WiFiManagerParameter {
  public:
    WiFiManagerParameter(const char *custom);
    WiFiManagerParameter(const char *id, const char *placeholder, const char *defaultValue, int length);
    WiFiManagerParameter(const char *id, const char *placeholder, const char *defaultValue, int length, const char *custom);

    const char *getID();
    const char *getValue();
    const char *getPlaceholder();
    int         getValueLength();
    const char *getCustomHTML();
  private:
    const char *_id;
    const char *_placeholder;
    char       *_value;
    int         _length;
    const char *_customHTML;

    void init(const char *id, const char *placeholder, const char *defaultValue, int length, const char *custom);

    friend class WiFiManager;
};


class WiFiManager
{
  public:
    WiFiManager();

    boolean       autoConnect();
    boolean       autoConnect(char const *apName, char const *apPassword = NULL);

    //if you want to always start the config portal, without trying to connect first
    boolean       startConfigPortal();
    boolean       startConfigPortal(char const *apName, char const *apPassword = NULL);

    // get the AP name of the config portal, so it can be used in the callback
    String        getConfigPortalSSID();

    void          resetSettings();

    //sets timeout before webserver loop ends and exits even if there has been no setup.
    //useful for devices that failed to connect at some point and got stuck in a webserver loop
    //in seconds setConfigPortalTimeout is a new name for setTimeout
    void          setConfigPortalTimeout(unsigned long seconds);
    void          setTimeout(unsigned long seconds);

    //sets timeout for which to attempt connecting, useful if you get a lot of failed connects
    void          setConnectTimeout(unsigned long seconds);


    void          setDebugOutput(boolean debug);
    //defaults to not showing anything under 8% signal quality if called
    void          setMinimumSignalQuality(int quality = 8);
    //sets a custom ip /gateway /subnet configuration
    void          setAPStaticIPConfig(IPAddress ip, IPAddress gw, IPAddress sn);
    //sets config for a static IP
    void          setSTAStaticIPConfig(IPAddress ip, IPAddress gw, IPAddress sn);
    //called when AP mode and config portal is started
    void          setAPCallback( void (*func)(WiFiManager*) );
    //called when settings have been changed and connection was successful
    void          setSaveConfigCallback( void (*func)(void) );
    //adds a custom parameter
    void          addParameter(WiFiManagerParameter *p);
    //if this is set, it will exit after config, even if connection is unsuccessful.
    void          setBreakAfterConfig(boolean shouldBreak);
    //if this is set, try WPS setup when starting (this will delay config portal for up to 2 mins)
    //TODO
    //if this is set, customise style
    void          setCustomHeadElement(const char* element);
    //if this is true, remove duplicated Access Points - defaut true
    void          setRemoveDuplicateAPs(boolean removeDuplicates);

  private:
    std::unique_ptr<DNSServer>        dnsServer;
    std::unique_ptr<ESP8266WebServer> server;

    //const int     WM_DONE                 = 0;
    //const int     WM_WAIT                 = 10;

    //const String  HTTP_HEAD = "<!DOCTYPE html><html lang=\"en\"><head><meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/><title>{v}</title>";

    void          setupConfigPortal();
    void          startWPS();

    const char*   _apName                 = "no-net";
    const char*   _apPassword             = NULL;
    String        _ssid                   = "";
    String        _pass                   = "";
    unsigned long _configPortalTimeout    = 0;
    unsigned long _connectTimeout         = 0;
    unsigned long _configPortalStart      = 0;

    IPAddress     _ap_static_ip;
    IPAddress     _ap_static_gw;
    IPAddress     _ap_static_sn;
    IPAddress     _sta_static_ip;
    IPAddress     _sta_static_gw;
    IPAddress     _sta_static_sn;

    int           _paramsCount            = 0;
    int           _minimumQuality         = -1;
    boolean       _removeDuplicateAPs     = true;
    boolean       _shouldBreakAfterConfig = false;
    boolean       _tryWPS                 = false;

    const char*   _customHeadElement      = "";

    //String        getEEPROMString(int start, int len);
    //void          setEEPROMString(int start, int len, String string);

    int           status = WL_IDLE_STATUS;
    int           connectWifi(String ssid, String pass);
    uint8_t       waitForConnectResult();

    void          handleRoot();
    void          handleWifi(boolean scan);
    void          handleWifiSave();
    void          handleInfo();
    void          handleReset();
    void          handleNotFound();
    void          handle204();
    boolean       captivePortal();
    boolean       configPortalHasTimeout();

    // DNS server
    const byte    DNS_PORT = 53;

    //helpers
    int           getRSSIasQuality(int RSSI);
    boolean       isIp(String str);
    String        toStringIp(IPAddress ip);

    boolean       connect;
    boolean       _debug = true;

    void (*_apcallback)(WiFiManager*) = NULL;
    void (*_savecallback)(void) = NULL;

    WiFiManagerParameter* _params[WIFI_MANAGER_MAX_PARAMS];

    template <typename Generic>
    void          DEBUG_WM(Generic text);

    template <class T>
    auto optionalIPFromString(T *obj, const char *s) -> decltype(  obj->fromString(s)  ) {
      return  obj->fromString(s);
    }
    auto optionalIPFromString(...) -> bool {
      DEBUG_WM("NO fromString METHOD ON IPAddress, you need ESP8266 core 2.1.0 or newer for Custom IP configuration to work.");
      return false;
    }
};

#endif
